﻿CREATE TABLE [dbo].[v_Underwriter] (
    [LoanNumber]    BIGINT        NULL,
    [CTI_FirstName] VARCHAR (255) NULL,
    [CTI_Surname]   VARCHAR (255) NULL
);

