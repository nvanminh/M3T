﻿CREATE TABLE [dbo].[iO_Test_StateTestInput] (
    [TSTsti_ID]             VARCHAR (40)  NULL,
    [TSTsti_Ownership]      VARCHAR (40)  NULL,
    [TSTsti_IDLink_Version] VARCHAR (40)  NULL,
    [TSTsti_IDLink_Sync]    VARCHAR (40)  NULL,
    [TSTsti_IDLink_TSTmr]   VARCHAR (40)  NULL,
    [TSTsti_SeqNumber]      BIGINT        NULL,
    [TSTsti_FieldName]      VARCHAR (255) NULL,
    [TSTsti_FieldId]        INT           NULL
);

