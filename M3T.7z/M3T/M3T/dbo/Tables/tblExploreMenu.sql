﻿CREATE TABLE [dbo].[tblExploreMenu] (
    [ImportDate]   DATETIME     NULL,
    [ItemName]     VARCHAR (50) NULL,
    [ItemCode]     VARCHAR (8)  NULL,
    [ItemOrder]    INT          NULL,
    [ItemText]     VARCHAR (99) NULL,
    [ExternalText] VARCHAR (99) NULL
);

