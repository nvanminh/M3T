﻿CREATE TABLE [dbo].[vwBorrowers] (
    [RMR_ID]                 VARCHAR (40) NULL,
    [CMR_ID]                 VARCHAR (40) NULL,
    [LMR_IDLink_Association] VARCHAR (40) NULL,
    [IsGuarantor]            BIT          NULL
);

