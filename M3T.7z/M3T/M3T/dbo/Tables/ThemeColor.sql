﻿CREATE TABLE [dbo].[ThemeColor] (
    [Control]  INT            NULL,
    [Property] VARCHAR (100)  NULL,
    [Value]    VARCHAR (4000) NULL,
    [Note]     VARCHAR (4000) NULL
);

