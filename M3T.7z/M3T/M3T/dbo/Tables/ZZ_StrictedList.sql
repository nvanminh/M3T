﻿CREATE TABLE [dbo].[ZZ_StrictedList] (
    [LapsClientID]  VARCHAR (50) NULL,
    [CMR_ID]        VARCHAR (50) NULL,
    [CMR_Seqnumber] VARCHAR (50) NULL
);

