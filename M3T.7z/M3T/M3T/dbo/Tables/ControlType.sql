﻿CREATE TABLE [dbo].[ControlType] (
    [XFRC_ControlType] INT           NULL,
    [XFRC_Name]        VARCHAR (255) NULL
);

