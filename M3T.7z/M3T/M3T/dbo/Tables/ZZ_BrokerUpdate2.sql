﻿CREATE TABLE [dbo].[ZZ_BrokerUpdate2] (
    [LoanPK]     VARCHAR (50) NULL,
    [LoanID]     VARCHAR (50) NULL,
    [LapsLoanNo] VARCHAR (50) NULL,
    [BID]        VARCHAR (50) NULL,
    [REF]        VARCHAR (50) NULL,
    [SubA]       VARCHAR (50) NULL,
    [SubB]       VARCHAR (50) NULL
);

