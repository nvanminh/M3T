﻿CREATE TABLE [dbo].[DuplicateClientFinal] (
    [Root_Client_SeqNum] VARCHAR (40)  NULL,
    [DuplicateList]      VARCHAR (MAX) NULL,
    [HasFunded]          BIT           NULL
);

