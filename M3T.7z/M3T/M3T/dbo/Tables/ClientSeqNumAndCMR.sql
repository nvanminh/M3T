﻿CREATE TABLE [dbo].[ClientSeqNumAndCMR] (
    [CMR_ID]        VARCHAR (40) NOT NULL,
    [CMR_SeqNumber] BIGINT       NULL
);

