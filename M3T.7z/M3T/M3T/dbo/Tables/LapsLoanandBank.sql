﻿CREATE TABLE [dbo].[LapsLoanandBank] (
    [LoanID]    FLOAT (53)     NULL,
    [BSBNo]     NVARCHAR (255) NULL,
    [AccountNo] FLOAT (53)     NULL
);

