﻿CREATE TABLE [dbo].[iO_GNW_Enumertions_ArmNetMapping] (
    [GNWenam_ID]             VARCHAR (40) NULL,
    [GNWenam_Ownership]      VARCHAR (40) NULL,
    [GNWenam_Version]        VARCHAR (40) NULL,
    [GNWenam_Sync]           VARCHAR (40) NULL,
    [GNWenam_IDLink_GNWenum] VARCHAR (40) NULL,
    [GNWenam_ArmNetValue]    VARCHAR (40) NULL
);

