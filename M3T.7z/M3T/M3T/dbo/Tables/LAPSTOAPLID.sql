﻿CREATE TABLE [dbo].[LAPSTOAPLID] (
    [RMR_ID]      NVARCHAR (255) NULL,
    [LAPS_LoanNo] FLOAT (53)     NULL,
    [APL_LoanNo]  FLOAT (53)     NULL
);

