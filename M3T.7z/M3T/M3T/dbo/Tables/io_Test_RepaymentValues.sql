﻿CREATE TABLE [dbo].[io_Test_RepaymentValues] (
    [RMR_ID]      VARCHAR (40) NULL,
    [ScriptValue] FLOAT (53)   NULL,
    [FieldValue]  FLOAT (53)   NULL
);

