﻿CREATE TABLE [dbo].[iO_FNF_FileStatusALL] (
    [FNFfsa_ID]               VARCHAR (40) NULL,
    [FNFfsa_IDLink_Ownership] VARCHAR (40) NULL,
    [FNFfsa_IDLink_Version]   VARCHAR (40) NULL,
    [FNFfsa_IDLink_Sync]      VARCHAR (40) NULL,
    [FNFfsa_IDLink_Code]      VARCHAR (40) NULL,
    [FNFfsa_IDLink_SCM]       VARCHAR (50) NULL,
    [FNFfsa_SeqNumber]        INT          NULL,
    [FNFfsa_FileNumber]       VARCHAR (50) NULL,
    [FNFfsa_Status]           VARCHAR (50) NULL
);

