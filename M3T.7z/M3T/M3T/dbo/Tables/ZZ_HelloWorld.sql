﻿CREATE TABLE [dbo].[ZZ_HelloWorld] (
    [MyDate] DATETIME NULL
);

