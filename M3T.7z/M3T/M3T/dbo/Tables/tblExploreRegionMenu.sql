﻿CREATE TABLE [dbo].[tblExploreRegionMenu] (
    [RegionID]    DECIMAL (18)  NULL,
    [Description] VARCHAR (511) NULL
);

