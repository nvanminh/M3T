﻿CREATE TABLE [dbo].[Testtable] (
    [Branch]      VARCHAR (512) NULL,
    [Customer]    VARCHAR (512) NULL,
    [CustID]      BIGINT        NOT NULL,
    [LoanID]      BIGINT        NOT NULL,
    [xtrm_IDUSer] INT           NULL,
    [ProdType]    VARCHAR (512) NULL
);

