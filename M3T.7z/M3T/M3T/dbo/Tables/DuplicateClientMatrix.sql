﻿CREATE TABLE [dbo].[DuplicateClientMatrix] (
    [CMR_SeqNumber]    NVARCHAR (MAX) NULL,
    [Dup_name_bob]     NVARCHAR (MAX) NULL,
    [Dup_dob_email]    NVARCHAR (MAX) NULL,
    [Dup_dob_mobile]   NVARCHAR (MAX) NULL,
    [Dup_dob_bank]     NVARCHAR (MAX) NULL,
    [Dup_name_email]   NVARCHAR (MAX) NULL,
    [Dup_name_mobile]  NVARCHAR (MAX) NULL,
    [Dup_name_bank]    NVARCHAR (MAX) NULL,
    [Dup_email_mobile] NVARCHAR (MAX) NULL,
    [Final_list]       NVARCHAR (MAX) NULL
);

