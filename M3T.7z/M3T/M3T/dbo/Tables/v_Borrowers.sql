﻿CREATE TABLE [dbo].[v_Borrowers] (
    [LMR_ID]                 VARCHAR (40) NULL,
    [RMR_ID]                 VARCHAR (40) NULL,
    [CMR_ID]                 VARCHAR (40) NULL,
    [LMR_IDLink_Association] VARCHAR (40) NULL,
    [IsGuarantor]            BIT          NULL
);

